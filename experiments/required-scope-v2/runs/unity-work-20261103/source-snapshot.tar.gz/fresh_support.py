import json
from pathlib import Path
def prepare_fresh(app,group,target,out):
    assert len(group['jobs'])==228
    expected=[j['case_id']for j in group['jobs']];assert len(set(expected))==228
    root=app.store.root/group['model']['id']
    assert not root.exists()or not list(root.glob('*.json')),'Fresh method run must never overwrite results'
    report={'eligible_by_current_identity':0,'new_required':228,'required_current':228,'entries':[],
            'target':target,'raw_records_or_ids_rewritten':False,'new_method_no_prior_trials_reused':True}
    (Path(out)/'reuse-manifest.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    (Path(out)/'all-current-case-ids.json').write_text(json.dumps(sorted(expected),indent=2),encoding='utf8')
    return report
def verify_matrix(app,mid,out):
    expected=set(json.loads((Path(out)/'all-current-case-ids.json').read_text()))
    rows=[app.store.read(p)for p in(app.store.root/mid).glob('*.json')]
    assert len(rows)==228 and {r['case_id']for r in rows}==expected
    assert len({(r['test_id'],r['variant_id'],r['repetition'])for r in rows})==228
    return rows
