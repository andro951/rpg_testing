"""One pinned model on one physical12GB GPU; no Perchance or CPU recovery."""
from pathlib import Path
import collections,copy,hashlib,json,os,platform,signal,sys,tarfile,threading,traceback
OUT=Path(__file__).resolve().parent;REPO=OUT/'repo';sys.path[:0]=[str(REPO),str(OUT)];os.chdir(REPO)
from workbench.controller import Controller
from workbench.domain import digest,implementation_fingerprint
from workbench.judgements import load_tests,review_lock
from workbench.scheduler import Session
from workbench.native import NativeBackend
from workbench.telemetry import GpuMonitor
from workbench.inventory import detect_gpus
from workbench.workflows import messages
from evaluation.core import assess_record
from fresh_support import prepare_fresh,verify_matrix
app=None;ended=threading.Event();session=None;reused=0
def now():
 from datetime import datetime,timezone
 return datetime.now(timezone.utc).isoformat()
def save(name,value):
 p=OUT/name;t=p.with_suffix(p.suffix+'.pending');t.write_text(json.dumps(value,indent=2),encoding='utf8');os.replace(t,p)
def stop(signum,frame):
 if app:app.control('stop')
for sig in(signal.SIGTERM,signal.SIGINT,signal.SIGUSR1):signal.signal(sig,stop)
class FixedContextSession(Session):
 def load(self,group,*args,**kwargs):
  if self.contexts[group['model']['id']]['allocated_tokens']!=32768:raise RuntimeError('Fixed context control changed before load')
  return super().load(group,*args,**kwargs)
def balance_pairs(jobs):
 keys=sorted({(j['test']['prompt_builder']['fixture'],j['variant']['id'],j['repetition']) for j in jobs})
 assert len(keys)==114 and len(jobs)==228
 rank={key:i for i,key in enumerate(keys)}
 def order(job):
  key=(job['test']['prompt_builder']['fixture'],job['variant']['id'],job['repetition'])
  method=job['test']['prompt_builder']['method'];assert method in ('research_json_v2','research_field_value_v2')
  arm=0 if method=='research_json_v2'else 1
  return (rank[key],arm^(rank[key]%2))
 jobs.sort(key=order)
 for i in range(0,len(jobs),2):
  a,b=jobs[i:i+2]
  assert (a['test']['prompt_builder']['fixture'],a['variant']['id'],a['repetition'])==(b['test']['prompt_builder']['fixture'],b['variant']['id'],b['repetition'])
  assert a['test']['prompt_builder']['method']!=b['test']['prompt_builder']['method']
def watch():
 while not ended.wait(5):
  if(OUT/'stop.request').exists():app.control('stop')
  s=app.snapshot();save('run-status.json',{'job_id':os.environ.get('SLURM_JOB_ID'),'at':now(),'state':s['state'],'processed':s['run_processed'],'total':228,'completed_current':reused+s['run_processed'],'reused_unchanged':reused,'new_required':s['run_total'],'current':s['current'],'progress':s['progress'],'failure':s['failure'],'errors':s['session_errors'],'automatic_activity_pause':False})
def seal():
 with tarfile.open(OUT/'evidence.tar.gz','w:gz')as tar:
  for name in('plan.json','preflight.json','launch-receipt.json','allocation.json','actual-prompt-manifest.json','fit.json','result.json','driver-error.json','run-status.json','reuse-manifest.json','all-current-case-ids.json'):
   p=OUT/name
   if p.exists():tar.add(p,arcname=name)
  for name in('results','.local/workbench/logs','.local/workbench/preflight_reports'):
   p=REPO/name
   if p.exists():tar.add(p,arcname='repo/'+name)
  tar.add(REPO/'source-manifest.json',arcname='repo/source-manifest.json')
 save('evidence-ready.json',{'sha256':hashlib.sha256((OUT/'evidence.tar.gz').read_bytes()).hexdigest(),'bytes':(OUT/'evidence.tar.gz').stat().st_size,'at':now()})
def main():
 global app,session,reused
 assert os.environ.get('SLURM_JOB_ID'),'Never load models on a login node'
 plan=json.loads((OUT/'plan.json').read_text());validation=json.loads((OUT/'validation.json').read_text());assert validation['software_checks_complete']and validation['prompt_audit_passed']
 source=json.loads((REPO/'source-manifest.json').read_text())
 for name,h in source['files'].items():assert hashlib.sha256((REPO/name).read_bytes()).hexdigest()==h,name
 wanted=json.loads((OUT/'prompt-manifest.json').read_text());actual=[]
 for t in load_tests(REPO/'test_specs'):
  for v in t['variants']:actual.append({'test_id':t['id'],'variant_id':v['id'],'repetitions':t['repetitions'],'message_digest':digest(messages(t,v['steps'][0],{},v))})
 assert len(actual)==76 and {p['message_digest']for p in actual}=={p['message_digest']for p in wanted['requests']}
 save('actual-prompt-manifest.json',{'requests':actual,'scope_digest':wanted['scope_digest'],'method':'required-scope-v2','exact_rendered_review':True})
 gpus=detect_gpus();assert len(gpus)==1 and 11.5<=gpus[0]['total_gib']<=12.25,gpus
 save('allocation.json',{'job_id':os.environ['SLURM_JOB_ID'],'host':os.uname().nodename,'gpu':gpus[0],'CUDA_VISIBLE_DEVICES':os.environ.get('CUDA_VISIBLE_DEVICES'),'one_model':plan['model_id'],'one_gpu':True,'inference_port':plan['inference_port'],'compiler_runtime_pinned':True})
 app=Controller(REPO);app.settings.update(sync_source=False,publish_results=False,inference_port=plan['inference_port']);watcher=threading.Thread(target=watch,daemon=True);watcher.start()
 try:
  with review_lock(REPO):
   report=app.check(selection={'model_id':plan['model_id']});save('preflight.json',report);assert report['ready'],report['issues'];assert not app.plan.get('perchance_plan')
   groups=[g for g in app.plan['groups']if g['jobs']];assert len(groups)==1 and groups[0]['model']['id']==plan['model_id'];group=groups[0];assert len(group['jobs'])==228 and group['context']['allocated_tokens']==32768
   reuse=prepare_fresh(app,group,app.plan['target'],OUT);reused=reuse['eligible_by_current_identity'];app.plan['pending']=reuse['new_required'];app.plan['complete']=reused
   balance_pairs(group['jobs'])
   app.state='running';app.started=now();app.run_total=reuse['new_required'];app.run_processed=0
   app.run_provenance={'backend_version':app.backend_version(),'python':platform.python_version(),'source_commit':None,'workflow_code':app.workflow_code(),'raw_implementation':implementation_fingerprint(),'selection':{'model_id':plan['model_id']},'experiment':'required-scope-v2','scope_digest':wanted['scope_digest'],'source_protocol':'paired-json-and-field-value-v2','prompt_review':'76 dot-path requests reviewed by Codex and coordinating thread','pair_order':'Adjacent matched cells; alternating first method across the 114 pairs','fixed_context_tokens':32768,'one_model_per_job':True,'inference_port':plan['inference_port'],'automatic_activity_pause':False,'cpu_recovery':False}
   save('launch-receipt.json',{'job_id':os.environ['SLURM_JOB_ID'],'at':now(),'model_id':plan['model_id'],'pending':reuse['new_required'],'reused_unchanged':reused,'required_current':228,'scope_digest':wanted['scope_digest'],'port':plan['inference_port'],'raw_implementation':implementation_fingerprint(),'source_files':len(source['files'])})
   session=FixedContextSession(app,report,app.plan,NativeBackend);mid=plan['model_id'];session.contexts[mid]=copy.deepcopy(group['context']);session.expansions[mid]=0
   receipt=json.loads((OUT/'launch-receipt.json').read_text());receipt['session_id']=session.id;save('launch-receipt.json',receipt)
   monitor=GpuMonitor(gpus[0]['uuid']);monitor.start();monitor.begin_case()
   try:session.load(group)
   finally:memory=monitor.end_case();monitor.close()
   load=app.backend.load_metadata;placement=load['placement'];peak=memory.get('sampled_peak_used_gib');lines=[l for l in app.backend.lines if 'KV buffer size'in l or('llama_kv_cache:'in l and'K ('in l)];f16=any('K (f16)'in l and'V (f16)'in l for l in lines)
   fit={'qualified':placement.get('status')=='full_gpu'and placement.get('gpu_layers')==placement.get('total_layers')==plan['expected_gpu_layers']and placement.get('cpu_layers')==0 and not placement.get('cpu_kv_evidence')and not placement.get('cpu_compute_evidence')and memory.get('status')=='available'and peak is not None and peak<=11.5 and gpus[0]['total_gib']-peak>=.5 and f16,'placement':placement,'memory':memory,'f16_kv_verified':f16,'kv_evidence':lines,'context_tokens':32768,'maximum_peak_gib':11.5,'minimum_headroom_gib':.5,'measured_headroom_gib':gpus[0]['total_gib']-peak if peak is not None else None,'benchmark_observations_started':False}
   save('fit.json',fit);assert fit['qualified'],'Pinned full-GPU fit gate failed; no benchmark trials started'
   app.backend.load_metadata['fit_qualification']={'report':'fit.json','sha256':digest(fit),'measured_headroom_gib':fit['measured_headroom_gib']}
   if app.backend.process.poll() is not None:raise RuntimeError('Native runtime exited during readiness/seed diagnostics; no benchmark trials started')
   remaining=session.run_cases(group,group['jobs']);assert not remaining,'Runtime qualification failed; no CPU recovery or altered-context rerun'
   session.close_model();rows=verify_matrix(app,mid,OUT)
   assert len(rows)==228 and all(r['status']=='completed'for r in rows),'Inspect incomplete/technical outcomes; never fill them with copied responses'
   app.state='finished';app.finished=now();save('result.json',{'status':'finished','job_id':os.environ['SLURM_JOB_ID'],'model_id':mid,'observations':len(rows),'new_observations':app.run_processed,'reused_unchanged':reused,'outcomes':dict(collections.Counter(assess_record(r)['objective_outcome']for r in rows)),'timeouts':sum(bool(r.get('timed_out'))for r in rows),'scope_digest':wanted['scope_digest'],'finished':now()});print(json.dumps(json.loads((OUT/'result.json').read_text())),flush=True)
 finally:
  ended.set();watcher.join(5)
  if session:session.close_model()
  if app:app.flush_logs()
try:main()
except BaseException as exc:
 save('driver-error.json',{'error':str(exc),'type':type(exc).__name__,'traceback':traceback.format_exc(),'job_id':os.environ.get('SLURM_JOB_ID'),'at':now()});raise
finally:seal()

