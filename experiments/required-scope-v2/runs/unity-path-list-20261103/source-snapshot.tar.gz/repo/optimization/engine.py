"""Durable OPRO sessions: origin gate, full task-type validation, local rankings."""
import copy
import math
import secrets
import time
import uuid
from datetime import datetime, timezone
from workbench.domain import code_fingerprint, digest, read_json
from workbench.judgements import JudgementStore, review_lock, definition_id
from workbench.workflows import Cancelled
from evaluation.core import assess_record
from .storage import Store
from .templates import LABELS, freeze, parse_candidate, projection
from .runtime import Runtime, discover
from .token_budget import plan as token_plan, round_context
from .feedback import EvidencePacket
from . import prompt_builder
from workbench.execution_policy import DoesNotFit

DEFAULTS = {'max_attempts': 20, 'temperature_min': .5, 'temperature_max': .9,
            'reasoning': False, 'manual_guidance': ''}


def now():
    return datetime.now(timezone.utc).isoformat()


def settings(value, allow_legacy=False):
    if allow_legacy and isinstance(value, dict):
        value = {key: val for key, val in value.items() if key not in ('context_tokens', 'output_reserve')}
    if not isinstance(value, dict) or set(value) - set(DEFAULTS):
        raise ValueError('Unknown optimization setting')
    result = {**DEFAULTS, **value}
    for key, lo, hi in (('max_attempts', 1, 10000),):
        if type(result[key]) is not int or not lo <= result[key] <= hi:
            raise ValueError('Invalid ' + key)
    for key in ('temperature_min', 'temperature_max'):
        if type(result[key]) not in (int, float) or not math.isfinite(result[key]) or not 0 <= result[key] <= 2:
            raise ValueError('Temperature must be finite and between 0 and 2.')
    if result['temperature_min'] > result['temperature_max']:
        raise ValueError('Minimum temperature exceeds maximum.')
    if type(result['reasoning']) is not bool:
        raise ValueError('Reasoning must be a boolean.')
    if not isinstance(result['manual_guidance'], str):
        raise ValueError('Manual optimizer guidance must be text.')
    if not result['manual_guidance'].strip():
        result['manual_guidance'] = ''
    return result


def create(app, payload, cohort=None):
    if set(payload) - {'generator_id', 'origin_model_id', 'settings', 'prompt_writer', 'target', 'source_result'}:
        raise ValueError('Unknown optimization session option')
    config = settings(payload.get('settings', {}))
    cohort = cohort or discover(app)
    if not cohort['models']:
        raise ValueError('No runnable models on this host.')
    writer = payload.get('prompt_writer', {'provider': 'local'})
    if not isinstance(writer, dict) or writer.get('provider') not in ('local', 'codex'):
        raise ValueError('Choose Local model or Codex for prompt writing.')
    if writer['provider'] == 'codex':
        from .codex import validate
        writer = validate(writer)
        generator = {'id': writer['model']}
    else:
        if set(writer) != {'provider'}:
            raise ValueError('Unknown local prompt-writer option')
        generator = next((m for m in cohort['models'] if m['id'] == payload.get('generator_id') and m['provider'] == 'native'), None)
        if generator is None:
            raise ValueError('Choose an installed runnable native optimizer model.')
    origin_model_id = payload.get('origin_model_id') or cohort['models'][0]['id']
    if not any(m['id'] == origin_model_id for m in cohort['models']):
        raise ValueError('Choose a runnable starting-case model.')
    scope = freeze(app.root,payload.get('target'))
    definition = read_json(app.root / 'optimization/definitions/array_move_patch.json')
    origin=scope['cases'][scope['layers'][0]['members'][0]]
    if origin['test'].get('prompt_builder',{}).get('version')=='database-v3':
        definition['id']='database_prompt_optimization'
        definition['target']={**scope['target'],'step_id':origin['variant']['result']['step']}
        definition['scope_plan']['task_type']=scope['task_type']
        definition['required_labels']['task_requirements']['binding']='Reviewed per-test database rules, operation contract and structure; preserve the exact required operations.'
        definition['prompt_files']['task_definition']='database-task.txt'
    session = {'schema_version': 1, 'id': uuid.uuid4().hex, 'created': now(), 'status': 'ready',
               'settings': config, 'prompt_writer': writer, 'generator_id': generator['id'], 'origin_model_id': origin_model_id, 'scope': scope, 'definition': definition,
               'cohort': cohort, 'cohort_history': [cohort], 'attempts': [], 'observations': [], 'message': '',
               'optimizer_system': (app.root / 'docs/prompt-optimization/optimizer-system.txt').read_text(encoding='utf-8'),
               'optimizer_user': (app.root / 'docs/prompt-optimization/optimizer-user-template.txt').read_text(encoding='utf-8')}
    session['prompt_builder'] = prompt_builder.snapshot(app.root, definition)
    if payload.get('source_result') is not None:
        from .selection import from_result
        source=payload['source_result']
        if not isinstance(source,dict) or set(source)!={'model_id','case_id'}:
            raise ValueError('Invalid saved starting result.')
        selected,record=from_result(app.root,source['model_id'],source['case_id'])
        if selected['target']['definition_id']!=scope['target']['definition_id']:
            raise ValueError('The saved result does not match the selected starting case.')
        session['source_result']=source
        session['source_result_evidence']=Store(app.root).evidence(session['id'],record)
    Store(app.root).save(session)
    return session


def trial_key(session, candidate, model, case, repetition):
    return digest({'workflow': session['scope']['workflow_fingerprint'], 'candidate': candidate,
                   'model_identity': model['identity'], 'condition': projection(case, candidate, model['provider'] == 'perchance'),
                   'repetition': repetition})


def score(session, candidate, models, records, members=None):
    members = members if members is not None else session['scope']['layers'][-1]['members']
    by_key = {r['trial_key']: r for r in records if r['status'] in ('completed', 'timeout')}
    needed = {}
    summary = []
    for model in models:
        for member in members:
            case = session['scope']['cases'][member]
            keys = set()
            for repetition in range(case['test'].get('repetitions', 1)):
                key = trial_key(session, candidate, model, case, repetition)
                keys.add(key)
                needed[key] = by_key.get(key)
            present = [by_key[k] for k in keys if k in by_key]
            summary.append({'model_id': model['id'], 'case_id': member, 'recorded': len(present), 'required': len(keys),
                            'passes': sum(r.get('pass', False) for r in present),
                            'percentage': 100 * sum(r.get('pass', False) for r in present) / len(present) if present else None})
    recorded = [r for r in needed.values() if r is not None]
    passed = sum(bool(r.get('pass')) for r in recorded)
    return {'complete': bool(needed) and len(recorded) == len(needed), 'required': len(needed),
            'recorded': len(recorded), 'passes': passed, 'percentage': 100 * passed / len(recorded) if recorded else None,
            'summary': summary}


def top_three(session, models, records):
    ranked = []
    seen = set()
    for attempt in session['attempts']:
        candidate = attempt.get('candidate')
        if candidate is None or digest(candidate) in seen:
            continue
        seen.add(digest(candidate))
        result = score(session, candidate, models, records)
        if result['complete']:
            ranked.append({'attempt': attempt['number'], 'candidate': candidate, **result})
    return sorted(ranked, key=lambda item: (-item['percentage'], item['attempt']))[:3]


def view(app, session_id):
    store = Store(app.root)
    session = store.load(session_id)
    records = store.observations(session)
    models = session['cohort']['models']
    from .coverage import directory, read_state
    coverage_key = digest({'session': session_id, 'candidate': top_three(session, models, records)[0]['candidate']}) if top_three(session, models, records) else None
    coverage = read_state(app.root, coverage_key) if coverage_key and (directory(app.root, coverage_key)/'state.json').exists() else None
    return {**session, 'coverage': coverage, 'top_three': top_three(session, models, records),
            'baseline': score(session, None, models, records),
            'attempts': [{**a, 'score': score(session, a['candidate'], models, records) if a.get('candidate') else None} for a in session['attempts']]}


def update_settings(app, session_id, value):
    """Explicit generator-only edits preserve test coverage and consumed attempts."""
    config = settings(value)
    store = Store(app.root)
    session = store.load(session_id)
    change = {'kind': 'generation_settings_change', 'previous': session['settings'], 'settings': config, 'at': now()}
    session.setdefault('configuration_history', []).append(store.evidence(session_id, change))
    session['settings'] = config
    session['updated'] = now()
    store.save(session)
    return session


def prune_order(history):
    def key(item):
        invalid = item.get('candidate') is None
        layer = item.get('layer', -1)
        percentage = item.get('score', {}).get('percentage')
        return (0 if invalid else 1, layer, percentage if percentage is not None else -1, item['number'])
    return sorted(history, key=key)


def generation_packet(session, models, records, store):
    top = top_three(session, models, records)
    protected_ids = {item['attempt'] for item in top}
    evidence_packet = EvidencePacket()
    # Saved records from other machines are preserved, but neither their scores
    # nor their failures should influence this host's optimization request.
    identities = {m['identity'] for m in models}
    ids = {m['id'] for m in models}
    local_records = [r for r in records if r.get('model_id') in ids and
                     (not r.get('model_identity') or r['model_identity'] in identities)]
    baseline = [evidence_packet.trial(r) for r in local_records if r.get('candidate') is None]
    def detailed(attempt):
        item = {key: copy.deepcopy(attempt[key]) for key in ('number', 'status', 'layer', 'feedback', 'candidate') if key in attempt}
        if item.get('candidate'):
            item['score'] = score(session, item['candidate'], models, records)
        evidence = attempt.get('response_evidence') or attempt.get('error_evidence')
        if evidence and not item.get('candidate'):
            response = store.get_evidence(session['id'], evidence)
            partial = response.get('partial_response') or response.get('partial') or {}
            item['generation'] = {'text': response.get('text', partial.get('text', '')),
                                  'finish_reason': response.get('finish_reason', partial.get('finish_reason'))}
        item['trials'] = [evidence_packet.trial(r) for r in local_records if r.get('candidate') == item.get('candidate') and item.get('candidate') is not None]
        return item
    history = [detailed(a) for a in session['attempts'] if a['number'] not in protected_ids]
    packet = {'experiment': session['definition']['id'], 'immutable_contract': session['definition']['candidate_control'],
              'required_labels': session['definition']['required_labels'], 'evaluation_policy': 'Unchanged objective oracles; benchmark reasoning off; full repetitions. Origin pass then complete task type on all current host models.',
              'current_machine_models': [{'id': m['id'], 'name': m.get('name', m['id']), 'identity': m['identity'], 'provider': m['provider']} for m in models],
              'scope': {'type': session['scope'].get('task_type', 'Array move'), 'cases': list(session['scope']['cases']), 'origin_model_id': session['origin_model_id']},
              'baseline_summary': score(session, None, models, records),
              'reference_evidence': baseline, 'top_three': top, 'history': history,
              'prompts': evidence_packet.prompts,
              'pruned_attempts': [], 'attempt_limit': session['settings']['max_attempts']}
    if session.get('source_result_evidence') and session['source_result']['model_id'] in ids:
        source=copy.deepcopy(store.get_evidence(session['id'],session['source_result_evidence']))
        source['evaluation']=assess_record(source)
        source['pass']=source['evaluation']['objective_outcome']=='PASS'
        packet['starting_result']=evidence_packet.trial(source)
    # Protected top-three exact templates and model/case summaries survive all pruning.
    return packet


def packet_messages(session, packet):
    import json
    if session.get('prompt_builder'):
        messages = prompt_builder.build(session, packet)
    else:
        messages = [{'role': 'system', 'content': session['optimizer_system']},
                    {'role': 'user', 'content': session['optimizer_user'].replace('{{optimization_packet_json}}', json.dumps(packet, ensure_ascii=False, indent=2))}]
    guidance = session.get('settings', {}).get('manual_guidance', '')
    if guidance:
        # Append only after LPIL assembly. User text is literal supplemental
        # writer context, never parsed/lowered/substituted as LPIL or supplied
        # by CandidateBackend to the evaluated model.
        messages[-1]['content'] += ('\n\n--- Supplemental manual guidance for the optimizer ---\n'
            'The following user-authored context is for prompt writing only. It does not expand the selected evaluation scope, change the benchmark contract or alter grading.\n'
            'Guidance text:\n' + guidance)
    return messages


def fit_packet(session, packet, token_count, limits):
    packet = copy.deepcopy(packet)
    context, reserve = limits['context_tokens'], limits['output_reserve']
    removable = prune_order(packet['history'])
    while True:
        messages = packet_messages(session, packet)
        count = token_count(messages)
        if count + reserve <= context:
            return messages, {'input_tokens': count, 'output_reserve': reserve, 'context_tokens': context,
                              'pruned_attempts': packet['pruned_attempts']}
        if not removable:
            error = ValueError(f'Protected task, baseline and top-three feedback needs {count} input tokens plus {reserve} output tokens, but the available context is {context}. No benchmark evidence was truncated.')
            error.evidence = {'input_tokens': count, 'output_reserve': reserve, 'context_tokens': context,
                              'input_bytes': sum(len(m['content'].encode('utf-8')) for m in messages)}
            raise error
        remove = removable.pop(0)
        packet['history'] = [a for a in packet['history'] if a['number'] != remove['number']]
        packet['pruned_attempts'].append(remove['number'])
        # Requests used only by omitted attempts must not remain as hidden bulk.
        referenced = {call['prompt_id'] for trial in packet.get('reference_evidence', [])
                      for call in trial.get('calls', []) if call.get('prompt_id')}
        referenced.update(call['prompt_id'] for attempt in packet['history'] for trial in attempt.get('trials', [])
                          for call in trial.get('calls', []) if call.get('prompt_id'))
        if 'prompts' in packet:
            packet['prompts'] = {key: value for key, value in packet['prompts'].items() if key in referenced}


def prepare_generation(session, packet, model, config, runtime, responses=()):
    limits = token_plan(model, packet_messages(session, packet), config['reasoning'], responses)
    ceiling = limits['native_tokens']
    load_attempts = []
    while True:
        allocated = limits['context_tokens']
        try:
            backend = runtime.generator(model, {**config, 'context_tokens': allocated})
        except DoesNotFit as exc:
            load_attempts.append({'context_tokens': allocated, 'status': 'gpu_memory_error',
                                  'error': str(exc), 'evidence': exc.evidence})
            ceiling = allocated // 2
            if ceiling < 1024:
                exc.evidence = {**exc.evidence, 'automatic_token_planning': load_attempts}
                raise
            limits['context_tokens'] = ceiling
            limits['output_reserve'] = min(limits['desired_output_reserve'], ceiling // 4)
            continue
        load_attempts.append({'context_tokens': allocated, 'status': 'loaded'})
        count = backend.token_count(packet_messages(session, packet))
        required = count + limits['output_reserve']
        if required > allocated and allocated < ceiling:
            limits['context_tokens'] = round_context(required, ceiling)
            limits['output_reserve'] = min(limits['desired_output_reserve'], limits['context_tokens'] // 4)
            continue
        try:
            messages, measured = fit_packet(session, packet, backend.token_count, limits)
        except ValueError as exc:
            exc.evidence = {**getattr(exc, 'evidence', {}), 'automatic_token_planning': load_attempts, 'plan': limits}
            raise
        context = {**limits, **measured, 'load_attempts': load_attempts,
                   'memory_context_ceiling': ceiling, 'output_limit_policy': 'EOS, manual stop or remaining allocated context',
                   'output_tokens_available': allocated - measured['input_tokens'] - 32}
        return backend, messages, context


class Engine:
    def __init__(self, app, session_id, runtime_factory=None):
        self.app, self.store = app, Store(app.root)
        self.session = self.store.load(session_id)
        self.runtime_factory = runtime_factory or Runtime
        self.runtime = None
        self.records = self.store.observations(self.session)

    def save(self, status=None, message=None):
        if status is not None:
            self.session['status'] = status
        if message is not None:
            self.session['message'] = message
            self.app.message = message
        self.session['updated'] = now()
        self.store.save(self.session)

    def boundary(self):
        if self.app.cancel_event.is_set():
            raise Cancelled('Optimization stopped; saved terminal trials remain complete.')
        if self.app.pause_requested:
            self.app.state = 'paused'
            self.save('paused', 'Paused at an inference boundary. Resume continues missing work.')
            while not self.app.resume_event.wait(.2):
                if self.app.cancel_event.is_set():
                    raise Cancelled('Stopped while paused')
            if self.app.cancel_event.is_set():
                raise Cancelled('Stopped while paused')
            self.app.state = 'running'
            self.save('running')

    def evaluate(self, candidate, models, members):
        terminal = {r['trial_key'] for r in self.records if r['status'] in ('completed', 'timeout')}
        rejected = JudgementStore(self.app.root).read()['entries']
        for model in models:
            for member in members:
                case = self.session['scope']['cases'][member]
                if rejected.get(case['definition_id'], {}).get('blocked'):
                    raise ValueError('A frozen member is now rejected and cannot run: ' + member)
                for repetition in range(case['test'].get('repetitions', 1)):
                    self.boundary()
                    key = trial_key(self.session, candidate, model, case, repetition)
                    if key in terminal:
                        continue
                    self.app.set_progress('optimization', 'Testing ' + model['id'] + ': ' + member, 0, 0,
                                          'Repetition ' + str(repetition + 1) + '; benchmark reasoning off')
                    record = {'kind': 'trial', 'trial_key': key, 'candidate': candidate, 'model_id': model['id'],
                              'model_identity': model['identity'], 'case_id': member, 'repetition': repetition,
                              'test_definition': case['test'], 'variant_definition': case['variant'],
                              'started': now(), 'status': 'started', 'pass': False,
                              'timeout_seconds': 300 if model['provider'] == 'perchance' else 120}
                    record['coverage_aliases'] = [other for other, definition in self.session['scope']['cases'].items()
                                                  if repetition < definition['test'].get('repetitions', 1)
                                                  and trial_key(self.session, candidate, model, definition, repetition) == key]
                    # Save the intention before inference, including interruptions.
                    self.store.evidence(self.session['id'], record)
                    try:
                        outcome = self.runtime.evaluate(model, case, candidate, repetition)
                        record.update(outcome, status='completed', timed_out=False,
                                      **{'pass': bool(outcome.get('score', {}).get('exact_match'))})
                    except Exception as exc:
                        partial = getattr(exc, 'partial', {})
                        record.update(partial if isinstance(partial, dict) else {})
                        if getattr(exc, 'partial_response', None) and not record.get('calls'):
                            record['calls'] = [exc.partial_response]
                        timed_out = getattr(self.runtime, 'trial_started', True) and (
                            getattr(self.runtime.backend, 'timed_out', False) or type(exc).__name__ == 'PerchanceTimeout')
                        record.update(status='aborted' if isinstance(exc, Cancelled) else 'timeout' if timed_out else 'error',
                                      timed_out=timed_out, error=str(exc))
                        record['evaluation'] = assess_record(record)
                        record['finished'] = now()
                        evidence = self.store.evidence(self.session['id'], record)
                        self.session['observations'].append(evidence)
                        self.records.append(record)
                        self.save()
                        if not timed_out:
                            raise
                        self.runtime.close()
                    else:
                        record['evaluation'] = assess_record(record)
                        record['finished'] = now()
                        evidence = self.store.evidence(self.session['id'], record)
                        self.session['observations'].append(evidence)
                        self.records.append(record)
                        self.save()
                    terminal.add(key)

    def generate(self, models):
        self.boundary()
        codex = self.session.get('prompt_writer', {}).get('provider') == 'codex'
        generator = ({'identity': digest(self.session['prompt_writer'])} if codex else
                     next((m for m in models if m['id'] == self.session['generator_id'] and m['provider'] == 'native'), None))
        if generator is None:
            raise ValueError('The selected generator is unavailable on this host. Saved candidates can still be evaluated here.')
        config = settings(self.session['settings'], allow_legacy=True)
        packet = generation_packet(self.session, models, self.records, self.store)
        responses = [self.store.get_evidence(self.session['id'], attempt['response_evidence'])
                     for attempt in self.session['attempts'] if attempt.get('response_evidence')]
        try:
            if codex:
                from .codex import Generator
                self.runtime.close()
                self.app.set_progress('optimization', 'Connecting to Codex', 0, None,
                                      'Resuming the session thread' if self.session.get('codex_thread') else 'Creating the session thread')
                backend = Generator(self.app, self.session, self.save)
                self.runtime.backend = backend
                self.app.backend = backend
                messages = packet_messages(self.session, packet)
                context = {'output_tokens_available': None, 'policy': 'Codex manages its context and compaction; exact feedback is saved',
                           'thread_id': self.session['codex_thread']['id']}
            else:
                backend, messages, context = prepare_generation(self.session, packet, generator, config, self.runtime, responses)
        except Exception as exc:
            key = self.store.evidence(self.session['id'], {'kind': 'generation_preparation_error', 'at': now(),
                'error': str(exc), 'evidence': getattr(exc, 'evidence', {}),
                'load_metadata': copy.deepcopy(getattr(self.runtime.backend, 'load_metadata', {}))})
            self.session.setdefault('preparation_errors', []).append(key)
            self.save()
            raise
        random = secrets.SystemRandom()
        sampling = {} if codex else {'temperature': random.uniform(config['temperature_min'], config['temperature_max']),
                                    'seed': random.randrange(2**32), 'top_p': 1, 'top_k': 0, 'min_p': 0}
        request = {'kind': 'generation_request', 'messages': messages, 'sampling': sampling, 'context': context,
                   'reasoning': self.session['prompt_writer']['effort'] if codex else config['reasoning'], 'generator_identity': generator['identity'], 'started': now(),
                   'timeout_seconds': None, 'timeout_policy': 'completion_or_manual_stop',
                   'load_metadata': copy.deepcopy(getattr(backend, 'load_metadata', {}))}
        if config['manual_guidance']:
            request.update(manual_guidance=config['manual_guidance'], manual_guidance_scope='prompt_writer_only',
                           manual_guidance_sha256=digest(config['manual_guidance']))
        if codex:
            request.update(prompt_writer=self.session['prompt_writer'], thread_id=self.session['codex_thread']['id'],
                           unsupported_controls=['temperature', 'seed', 'local_reasoning_toggle'],
                           applied_controls={'model': self.session['prompt_writer']['model'], 'effort': self.session['prompt_writer']['effort']})
        attempt = {'number': len(self.session['attempts']) + 1, 'status': 'generating', 'layer': -1,
                   'request_evidence': self.store.evidence(self.session['id'], request)}
        self.session['attempts'].append(attempt)
        self.save('running', 'Generating candidate ' + str(attempt['number']))
        if codex:
            self.app.set_progress('optimization', 'Codex is writing a prompt', 0, None,
                                  self.session['prompt_writer']['model'] + ' · ' + self.session['prompt_writer']['effort'])
        try:
            response = backend.propose(messages, sampling, context['output_tokens_available'], self.app.cancel_event)
            attempt['response_evidence'] = self.store.evidence(self.session['id'], {'kind': 'generation_response', **response})
            if response.get('finish_reason') != 'stop':
                raise ValueError('Generator did not complete normally: ' + str(response.get('finish_reason')))
            if self.session.get('prompt_builder'):
                candidate = prompt_builder.parse_output(response['text'], self.session['prompt_builder'])
                if not isinstance(candidate, dict):
                    raise ValueError('The Array move benchmark executor needs candidate system/user messages. Custom artifacts can be built and validated separately.')
            else:
                candidate = parse_candidate(response['text'], self.session['definition']['required_labels'])
            attempt['candidate'] = candidate
            if any(a.get('candidate') == candidate for a in self.session['attempts'][:-1]):
                attempt.update(status='duplicate', feedback='Duplicate template pair; attempt saved, no duplicate trials or ranking slot.')
            else:
                attempt['status'] = 'evaluating'
        except ValueError as exc:
            attempt.update(status='invalid', feedback=str(exc))
        except Exception as exc:
            attempt.update(status='interrupted' if isinstance(exc, Cancelled) else 'generation_error', feedback=str(exc))
            attempt['error_evidence'] = self.store.evidence(self.session['id'], {'kind': 'generation_error', 'message': str(exc),
                'partial_response': getattr(exc, 'partial_response', {}), 'partial': getattr(exc, 'partial', {})})
            self.save()
            raise
        self.save()
        return attempt

    def run(self, mode='optimize', cohort=None):
        with review_lock(self.app.root):
            if code_fingerprint() != self.session['scope']['workflow_fingerprint']:
                raise ValueError('Workflow changed since this session was frozen; create a new reviewed session.')
            available = {}
            for path in (self.app.root / 'test_specs').glob('*.json'):
                test = read_json(path)
                if test.get('enabled', True):
                    available[test['id']] = {v['id']:definition_id(test,v) for v in test['variants'] if v.get('enabled', True)}
            for member, case in self.session['scope']['cases'].items():
                if case['variant']['id'] not in available.get(case['test']['id'], set()):
                    raise ValueError('This optimization session uses an archived or disabled test and cannot run: ' + member +
                                     '. Saved evidence is preserved. Start a new session after reviewing the current suite.')
                if available[case['test']['id']][case['variant']['id']]!=case['definition_id']:
                    raise ValueError('This optimization session uses a test definition that has changed: '+member+
                                     '. Saved evidence is preserved. Start a new session for the current test.')
            if mode == 'optimize' and not self.session.get('prompt_builder') and not self.session['attempts']:
                # A preparation failure consumed no candidate. Adopt the corrected
                # writer for the next request without changing frozen tests or
                # overwriting original messages, results or error evidence.
                config = prompt_builder.snapshot(self.app.root, self.session['definition'])
                evidence = self.store.evidence(self.session['id'], {'kind': 'prompt_builder_adopted',
                    'at': now(), 'previous': 'legacy-packet', 'prompt_builder': config})
                self.session.setdefault('configuration_history', []).append(evidence)
                self.session['prompt_builder'] = config
                self.save()
            cohort = cohort or discover(self.app)
            # Optimization resumes use their original local cohort. Cross-machine
            # evaluation deliberately establishes a new local comparison cohort.
            if mode == 'evaluate_remaining':
                self.session['cohort'] = cohort
                self.session['cohort_history'].append(cohort)
            else:
                identities = {m['identity'] for m in cohort['models']}
                if any(m['identity'] not in identities for m in self.session['cohort']['models']):
                    raise ValueError('A frozen host model is unavailable. Restore it, or use Evaluate remaining on this machine; it cannot silently leave the cohort.')
                by_identity = {m['identity']: m for m in cohort['models']}
                cohort = {**cohort, 'models': [by_identity[m['identity']] for m in self.session['cohort']['models']]}
                self.session['cohort'] = cohort
            if not cohort['models']:
                raise ValueError('No runnable models on the execution host.')
            for attempt in self.session['attempts']:
                if attempt['status'] == 'generating':
                    attempt.update(status='interrupted', feedback='Previous process ended after saving this generation request. No completed proposal was recorded; this attempt remains consumed.')
            self.runtime = self.runtime_factory(self.app, cohort)
            self.app.pause_requested = False
            self.app.resume_event.set()
            self.save('running')
            try:
                full = self.session['scope']['layers'][-1]['members']
                origin = self.session['scope']['layers'][0]['members']
                remote_models = [m for m in cohort['models'] if m['provider'] == 'perchance']
                candidates = [None] + [a['candidate'] for a in self.session['attempts'] if a.get('candidate') and
                                      (mode == 'evaluate_remaining' or a['status'] == 'evaluating')]
                ranked = top_three(self.session, cohort['models'], self.records)
                future_generation = (mode == 'optimize' and len(self.session['attempts']) < self.session['settings']['max_attempts']
                                     and not (ranked and ranked[0]['percentage'] == 100))
                remote_pending = bool(remote_models) and (future_generation or any(not score(self.session, candidate, remote_models, self.records)['complete'] for candidate in candidates))
                if remote_pending:
                    from workbench.perchance_setup import prepare
                    from workbench.perchance import MODEL_ID
                    prepare(self.app, selection={'model_id': MODEL_ID}, force_pending=True)
                    self.session['perchance_setup'] = copy.deepcopy(self.app.perchance_setup_decision)
                    if self.app.perchance_setup_decision['status'] in ('declined', 'failed'):
                        # Keep the frozen provider in coverage, but do native work.
                        models = [m for m in cohort['models'] if m['provider'] != 'perchance']
                    else:
                        models = cohort['models']
                else:
                    models = cohort['models']
                if mode == 'evaluate_remaining':
                    self.evaluate(None, models, full)
                    for attempt in self.session['attempts']:
                        if attempt.get('candidate') and attempt['status'] != 'duplicate':
                            self.evaluate(attempt['candidate'], models, full)
                    complete = all(score(self.session, a['candidate'], cohort['models'], self.records)['complete']
                                   for a in self.session['attempts'] if a.get('candidate') and a['status'] != 'duplicate')
                    self.save('finished' if complete else 'pending', 'Saved candidates evaluated on this host; no new generation attempts. Unavailable provider work remains pending.')
                    return
                # Baseline is pinned to the original definitions, not a generated
                # template. All candidate comparisons use identical cohort/cases.
                self.evaluate(None, models, full)
                while True:
                    self.boundary()
                    attempt = next((a for a in self.session['attempts'] if a['status'] == 'evaluating'), None)
                    ranked = top_three(self.session, cohort['models'], self.records)
                    if ranked and ranked[0]['percentage'] == 100:
                        self.save('perfect', '100% on every required current-host trial. Other hosts can evaluate remaining later.')
                        break
                    if attempt is None:
                        if len(self.session['attempts']) >= self.session['settings']['max_attempts']:
                            self.save('attempt_limit', 'Attempt limit reached. All proposals and evidence retained.')
                            break
                        attempt = self.generate(cohort['models'])
                    if attempt['status'] != 'evaluating':
                        continue
                    origin_models = [m for m in cohort['models'] if m['id'] == self.session['origin_model_id']]
                    if not origin_models:
                        raise ValueError('The starting-case model is unavailable on this host.')
                    self.evaluate(attempt['candidate'], [m for m in models if m['id'] == self.session['origin_model_id']], origin)
                    result = score(self.session, attempt['candidate'], origin_models, self.records, origin)
                    attempt['layer'] = 0
                    if not result['complete']:
                        self.save('pending', 'Provider work remains pending; resume on this host to finish the origin gate.')
                        break
                    if result['percentage'] != 100:
                        attempt.update(status='origin_failed', feedback='Starting case did not pass all configured repetitions on the selected starting model.')
                        self.save()
                        continue
                    attempt['layer'] = 1
                    self.evaluate(attempt['candidate'], models, full)
                    result = score(self.session, attempt['candidate'], cohort['models'], self.records)
                    if not result['complete']:
                        self.save('pending', 'Full task-type coverage is incomplete. No partial candidate enters the top three.')
                        break
                    attempt.update(status='complete', feedback='Full task type evaluated; rank by pooled current-host success percentage.')
                    self.save()
            except Cancelled:
                self.save('stopped', 'Stopped. Resume keeps completed pass/fail/timeout observations and consumed attempts.')
                raise
            except Exception as exc:
                self.save('blocked', str(exc))
                raise
            finally:
                self.runtime.close()


def dispatch(app, payload):
    mode = payload.get('mode', 'optimize')
    if mode not in ('optimize', 'evaluate_remaining'):
        raise ValueError('Unknown optimizer operation')
    session_id = payload.get('session_id')
    if session_id is None:
        session_id = create(app, {k: v for k, v in payload.items() if k in ('generator_id', 'origin_model_id', 'settings', 'prompt_writer','target','source_result')})['id']
    Engine(app, session_id).run(mode)
    from .coverage import after_success
    after_success(app, session_id)
