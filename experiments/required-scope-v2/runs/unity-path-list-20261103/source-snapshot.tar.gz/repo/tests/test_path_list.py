import copy,unittest
from workbench.path_list import apply,decode,encode
class PathListTests(unittest.TestCase):
 def test_nested_id_update_and_deletion(self):
  schema={'type':'object','properties':{'items':{'type':'array','x-id-field':'id','items':{'type':'object','properties':{'id':{'type':'string'},'n':{'type':'integer'}},'required':['id','n'],'additionalProperties':False}}},'required':['items'],'additionalProperties':False};state={'items':[{'id':'a,b].x','n':1},{'id':'b','n':2}]};original=copy.deepcopy(state)
  self.assertEqual(apply(state,'set [items, a%2Cb%5D%2Ex, n]: 9',schema)['items'][0]['n'],9)
  self.assertEqual(apply(state,'remove [items, a%2Cb%5D%2Ex]',schema),{'items':[{'id':'b','n':2}]})
  self.assertEqual(apply(state,'append [items]: {"id":"c","n":3}',schema)['items'][-1],{'id':'c','n':3});self.assertEqual(state,original)
  for bad in ('remove [items, b]: null','set [items, b, n]','set [items, b, n]: NaN','remove [items, 0]','append [items]: {"id":"b","n":3}','set [items, b, missing]: 1','set [items,,n]: 1','set [items, "b", n]: 1'):
   with self.subTest(bad=bad),self.assertRaises(Exception):apply(state,bad,schema)
 def test_roundtrip_and_ambiguous(self):
  ops=[{'op':'replace','path':'items.a%2Cb.n','value':'new\nline'},{'op':'remove','path':'items.b'}];self.assertEqual(decode(encode(ops)),ops);self.assertEqual(decode('none'),[])
  schema={'type':'object','properties':{'items':{'type':'array','items':{'type':['string','number']}}},'required':['items'],'additionalProperties':False}
  with self.assertRaisesRegex(ValueError,'Ambiguous'):apply({'items':[42,'42']},'remove [items, 42]',schema)
if __name__=='__main__':unittest.main()

